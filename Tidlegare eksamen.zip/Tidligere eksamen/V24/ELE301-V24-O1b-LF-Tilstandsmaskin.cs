﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace V24_O1b_LF
{
    enum EnTilstand { START, F, FO, FOS, FOSF, FOSFO }
    enum EnHendelse { F, O, S, R, ANNET }  // ANNET tilsvarer # som vi brukte tidligere
    enum EnAksjon { UTSKRIFT }   // Skal skrive "Funn"
    internal class Tilstandsmaskin
    {

        // Tilstandsmaskin-objekter må ha tilstand (private?)
        // Må ha et funksjonsmedlem som heter f.eks. HåndterEnHendelse
        // HåndterEnHendelse må motta hendelse og returnere liste av aksjoner 
        // Lista av aksjoner kan noen ganger være tom

        EnTilstand Tilstand;

        // Konstruktør
        public Tilstandsmaskin()
        {
            Tilstand = EnTilstand.START;
        }

        public List<EnAksjon> HåndterEnHendelse(EnHendelse Hendelse)
        {
            List<EnAksjon> Aksjonsliste = new List<EnAksjon>();

            // Ytre switch (lar ytre switch være på tilstand i denne versjonen)
            switch (Tilstand)
            {
                case EnTilstand.START:
                    // Indre switch 
                    switch (Hendelse)
                    {
                        case EnHendelse.F:
                            Tilstand = EnTilstand.F;
                            break;
                            // Alle andre hendelser medfører at vi blir værende i Tilstand.START
                    }
                    break;
                case EnTilstand.F:
                    // Indre switch  
                    switch (Hendelse)
                    {
                        case EnHendelse.F:
                            Tilstand = EnTilstand.F; // Streng tatt ikke nødvendig siden
                                                     // Vi allerede er i denne tilstanden
                            break;
                        case EnHendelse.O:
                            Tilstand = EnTilstand.FO;
                            break;
                        case EnHendelse.S:
                        case EnHendelse.R:
                        case EnHendelse.ANNET:
                            Tilstand = EnTilstand.START;
                            break;
                    }
                    break;
                case EnTilstand.FO:
                    // Indre switch 
                    switch (Hendelse)
                    {
                        case EnHendelse.F:
                            Tilstand = EnTilstand.F; 
                            break;
                        case EnHendelse.S:
                            Tilstand = EnTilstand.FOS;
                            break;
                        case EnHendelse.O:
                        case EnHendelse.R:
                        case EnHendelse.ANNET:
                            Tilstand = EnTilstand.START;
                            break;
                    }
                    break;
                case EnTilstand.FOS:
                    // Indre switch
                    switch (Hendelse)
                    {
                        case EnHendelse.F:
                            Tilstand = EnTilstand.FOSF;
                            break;
                        case EnHendelse.S: 
                        case EnHendelse.O:
                        case EnHendelse.R:
                        case EnHendelse.ANNET:
                            Tilstand = EnTilstand.START;
                            break;
                        }
                        break;
                case EnTilstand.FOSF:
                    // Indre switch 
                    switch (Hendelse)
                    {
                        case EnHendelse.F:
                            Tilstand = EnTilstand.F;
                            break;
                        case EnHendelse.O:
                            Tilstand = EnTilstand.FOSFO;
                            break;
                        case EnHendelse.S:
                        case EnHendelse.R:
                        case EnHendelse.ANNET:
                            Tilstand = EnTilstand.START;
                            break;
                    }
                    break;
                case EnTilstand.FOSFO:
                    // Indre switch 
                    switch (Hendelse)
                    {
                        case EnHendelse.F:
                            Tilstand = EnTilstand.F;
                            break;
                        case EnHendelse.R:
                            Tilstand = EnTilstand.START;
                            Aksjonsliste.Add(EnAksjon.UTSKRIFT);
                            break;
                        case EnHendelse.S:
                            Tilstand = EnTilstand.FOS;
                            break;
                        case EnHendelse.O:
                        case EnHendelse.ANNET:
                            Tilstand = EnTilstand.START;
                            break;
                    }
                    break;
            }

            return Aksjonsliste;
        } // slutten på HåndterEnHendelse
    }
}
