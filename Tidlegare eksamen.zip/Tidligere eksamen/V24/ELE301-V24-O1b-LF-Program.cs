﻿namespace V24_O1b_LF
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //====================================================================
            // PS: Oppgaven krever ikke at det lages testprogram slik som nedenfor
            //====================================================================
 
            Console.WriteLine("Du kan nå teste tilstandsmskinen ved å taste tegn:");

            // Variabler
            EnHendelse hendelse = EnHendelse.ANNET;
            List<EnAksjon> Aksjonsliste;

            // Oppretter et tilstandsmaskin-objekt for bruk her
            Tilstandsmaskin minTM = new Tilstandsmaskin();


            while (true)
            {
                // Motta en hendelse

                hendelse = MottaEnHendelse();

                Aksjonsliste = minTM.HåndterEnHendelse(hendelse);

                foreach (EnAksjon a in Aksjonsliste)
                {
                    if (a == EnAksjon.UTSKRIFT)
                    {
                        Console.WriteLine("FUNN");
                    }
                }


            }

        }

        static EnHendelse MottaEnHendelse()
        {
            EnHendelse svar = EnHendelse.ANNET;

            char input = Console.ReadKey().KeyChar;
            input = char.ToUpper(input);

            switch (input)
            {
                case 'F':
                    svar = EnHendelse.F;
                    break;
                case 'O':
                    svar = EnHendelse.O;
                    break;
                case 'S':
                    svar = EnHendelse.S;
                    break;
                case 'R':
                    svar = EnHendelse.R;
                    break; 
                default:
                    svar = EnHendelse.ANNET;
                    break;

            }
            return svar;

        }
    }

}
