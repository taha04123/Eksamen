﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace O2
{
    class Program
    {
        static void Main(string[] args)
        {
            const int ANTALL = 3;
            int[] tab = new int[ANTALL];
            Random r = new Random();

            /* Kode som starter trådene - punkt a */
            


            /* Kode som venter på at trådene er ferdige  - punkt b */



            for (int i = 0; i < tab.Length; i++)
            {
                Console.WriteLine($"Tråd {i + 1} har registrert antallet: {tab[i]}");
            }
            Console.WriteLine($"Summen: {tab.Sum()}");

        }

        static void Arbeid(object o)
        {
            /* Kode skal håndterer argumentoverføring - punkt c */



            for (int i = 0; i < 10; ++i)
            {
                
                int sovetid = r.Next(10, 31);
               
                Thread.Sleep(sovetid);

                int antall = r.Next(100);
    
                Console.Write($"Tråd {posisjon} - ");
                Console.WriteLine($"flere forekomster registrert: {antall}");
           
                tab[posisjon] = tab[posisjon] + antall;
              
            }
        }

    }
}
