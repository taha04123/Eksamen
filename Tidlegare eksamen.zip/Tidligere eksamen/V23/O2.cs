﻿namespace O2
{
    internal class Program
    {
        static Random r = new Random();

        static void Main(string[] args)
        {
            
        }

        static void JobbA(object o)
        {
            int x = (int)o;

            Thread.Sleep(r.Next(100, 200));
            Console.WriteLine("{0}: jobb ... ", x);
            int verdi = r.Next(100, 201);
            Thread.Sleep(r.Next(100,200));
            Console.WriteLine("{0}: beregnet verdi {1} ", x, verdi);
            Thread.Sleep(r.Next(100, 200));
            Console.WriteLine("{0}: jobb ... ", x + 1);
            verdi = r.Next(100, 201);
            Thread.Sleep(r.Next(100, 200));
            Console.WriteLine("{0}: beregnet verdi {1} ", x + 1, verdi);
        }

        static void JobbB(object o)
        {
            int x = (int)o;

            for (int i = 0; i < 3; i++)
            {
                Thread.Sleep(r.Next(100, 200));
                Console.WriteLine("{0}: jobber ... ", x + i);
                int verdi = r.Next(100, 201);
                Thread.Sleep(r.Next(100, 200));
                Console.WriteLine("{0}: beregnet verdi {1} ", x + i, verdi);
            }
        }

    }
}